#!/usr/bin/env bash
set -euo pipefail
composer install --no-interaction --prefer-dist
